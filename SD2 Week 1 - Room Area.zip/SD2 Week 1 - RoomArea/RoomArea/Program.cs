﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomSize
{
    class Program
    {
        static float area;

        static List<string> roomList = new List<string>();

        static void Main()
        {
            float areaTotal = 0; //Declare a float, string, and boolean
            string answer;
            bool again = true;
            while (again == true) //Loop to ask if they want to add another room
            {
                Console.WriteLine("Name your room: ");
                string x = Console.ReadLine();
                Room(x); //Runs a function to calculate room size
                Console.WriteLine("Would you like to add another room?");
                answer = Console.ReadLine();
                areaTotal = areaTotal + Program.area; //Works out the total area of the property
                if (answer == "No" || answer == "no")
                {
                    again = false; //Terminates loop
                }
            }
            roomList.ForEach(Console.WriteLine);
            Console.WriteLine("Total area is " + areaTotal + " metres squared.");
            Console.ReadKey();
        }

        static void Room(string room) //Function to calculate the size of the room
        {
            float length;
            float width;
            Console.WriteLine("Please enter the length of the room: "); //Gets the length of the room
            length = float.Parse(Console.ReadLine());
            Console.WriteLine("Please enter the width of the room: "); //Gets the width of the room
            width = float.Parse(Console.ReadLine());
            Program.area = length * width; //Calculates the area of the room
            Console.WriteLine("The area of the " + room + " is " + area + " metres squared");
            roomList.Add(room); //Adds the room to the list
            roomList.Add(area.ToString("0.00")); //Adds the room's area to the list
        }
    }
}