﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberList
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a number"); //Gets a number from user
            int inputNumber = Int32.Parse(Console.ReadLine()); //Saves this number as integer 'inputNumber'


            for (int x = 2; x < inputNumber; x++) //Loop that will repeat until the input number is reached
            {
                int isPrime = 0; //Create an integer 'isPrime'
                for (int y = 1; y < x; y++)
                {
                    if (x % y == 0) //If the number isn't prime...
                        isPrime++; //...increase the counter

                    if (isPrime == 2) break;
                }
                if (isPrime != 2) //If the number is prime...
                    Console.WriteLine(x); //...print the number

                isPrime = 0;
            }
            Console.ReadKey(); //User must press a key to exit the program
        }
    }
}