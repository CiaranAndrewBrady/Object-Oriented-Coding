﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace DataLayer
{
    public class SaveLoad
    {
        public static void Main()
        {
        }

        public static void Save()
        {
            XmlSerializer SaveTrainFunction = new XmlSerializer(typeof(Train));
            XmlSerializer SaveCustomerFunction = new XmlSerializer(typeof(Customer));

            TextWriter WriteFile = new StreamWriter(Directory.GetCurrentDirectory() + @"\SavedData.xml");
            foreach (Train counter in TrainList._trainList)
            {
                SaveTrainFunction.Serialize(WriteFile, counter);
            }
            foreach (Customer counter in CustomerList._customerList)
            {
                SaveCustomerFunction.Serialize(WriteFile, counter);
            }
            WriteFile.Close();
        }
    }
}
