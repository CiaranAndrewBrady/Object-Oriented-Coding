﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class Customer
    {
        private string _name;
        private string _trainID;
        private string _customerDepartureStation;
        private string _customerArrivalStation;
        private Boolean _cabin = false;
        private Boolean _firstClass = false;
        private string _coachValue;
        private string _seatNumber;

        public string Name { get => _name; set => _name = value; }
        public string TrainID { get => _trainID; set => _trainID = value; }
        public string CustomerDepartureStation { get => _customerDepartureStation; set => _customerDepartureStation = value; }
        public string CustomerArrivalStation { get => _customerArrivalStation; set => _customerArrivalStation = value; }
        public bool Cabin { get => _cabin; set => _cabin = value; }
        public bool FirstClass { get => _firstClass; set => _firstClass = value; }
        public string CoachValue { get => _coachValue; set => _coachValue = value; }
        public string SeatNumber { get => _seatNumber; set => _seatNumber = value; }
    }
}
