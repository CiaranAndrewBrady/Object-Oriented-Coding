﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class TrainList
    {
        public static List<Train> _trainList = new List<Train>();

        public void add(Train newTrain)
        {
            _trainList.Add(newTrain);
        }

        public Train find(string train)
        {
            foreach (Train c in _trainList)
            {
                if (train == c.TrainID)
                {
                    return c;
                }
            }

            return null;
        }
    }
}
