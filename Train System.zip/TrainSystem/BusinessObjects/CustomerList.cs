﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class CustomerList
    {
        public static List<Customer> _customerList = new List<Customer>();

        public void add(Customer newCustomer)
        {
            _customerList.Add(newCustomer);
        }
    }
}
