﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects
{
    public class Train
    {
        private string _trainID;
        private string _departureStation;
        private string _destinationStation;
        private string _trainType;
        private string _intermediates;
        private DateTime _time;
        private DateTime _date;
        private Boolean _isSleeper;
        private Boolean _isFirstClass;

        public string TrainID { get => _trainID; set => _trainID = value; }
        public string DepartureStation { get => _departureStation; set => _departureStation = value; }
        public string DestinationStation { get => _destinationStation; set => _destinationStation = value; }
        public string TrainType { get => _trainType; set => _trainType = value; }
        public string Intermediates { get => _intermediates; set => _intermediates = value; }
        public DateTime Time { get => _time; set => _time = value; }
        public DateTime Date { get => _date; set => _date = value; }
        public bool IsSleeper { get => _isSleeper; set => _isSleeper = value; }
        public bool IsFirstClass { get => _isFirstClass; set => _isFirstClass = value; }
    }
}
