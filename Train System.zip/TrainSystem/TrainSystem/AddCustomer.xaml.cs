﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TrainSystem
{
    /// <summary>
    /// Interaction logic for AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : Window
    {
        public static Customer store = new Customer();
        public static CustomerList list = new CustomerList();

        public AddCustomer()
        {
            InitializeComponent();
        }

        //Initialisation
        bool hasSeenCost = false; //This boolean is used to ensure that the user cannot make a booking without first viewing the cost
        bool trainExists = false; //This boolean is used to ensure that the train they are attempting to book is actually real
        bool seatTaken = false; //This boolean is used to check if the user's seat is taken

        string name = null; //Creates 'name', 'trainID', 'origin', 'destination', 'coach', and 'seat' as blank strings
        string trainID = null;
        string origin = null;
        string destination = null;
        string coach = null;
        string seat = null;
        bool cabin = false; //Creates 'cabin' and 'firstClass' as blank booleans
        bool firstClass = false;

        private void Btn_getFareCost_Click(object sender, RoutedEventArgs e) //Calulates the user's fare and enables them to finalise the booking
        {
            name = txt_name.Text; //User inputs name, saved as string
            trainID = txt_trainID.Text; //User inputs train ID, saved as string
            origin = ddl_origin.Text; //User inputs origin, saved as string
            destination = ddl_destination.Text; //User inputs destination, saves as string
            if (cbx_cabin.IsChecked == true) //If the user ticks the cabin checkbox
            {
                cabin = true; //...then the train has a cabin.
            }
            if (cbx_firstClass.IsChecked == true) //If the user ticks the first class checkbox
                {
                firstClass = true; //...then the train offers first class.
                }
            coach = ddl_coach.Text; //User selects coach, saves as string
            seat = ddl_seat.Text; //User selects seat, saves as string

            //Validation
            try
            {
                foreach (Customer counter in CustomerList._customerList) //Searches the entire customer list, one at a time
                {
                    if (counter.TrainID == trainID && counter.CoachValue == coach && counter.SeatNumber == seat)
                    { seatTaken = true; } //If the train ID, coach value, and seat number all line up in a pre-existing record, the seat is marked as taken
                }
                foreach (Train counter in TrainList._trainList) //Searches the entire train list, one at a time
                {
                    if (counter.TrainID == trainID)
                    { trainExists = true; } //If the train ID exists, then it is marked as such, otherwise, it will stay false and trigger a popup later
                }
                if (name == "") //Ensures that the user does not leave the 'name' section blank
                { MessageBox.Show("Please enter a name."); }
                else if (trainID == "") //Ensures that the user does not leave the train ID section blank
                { MessageBox.Show("Please enter a train ID."); }
                else if (trainExists == false) //If we didn't validate the train as real in the previous foreach, then we throw a popup
                { MessageBox.Show("This train does not exist, please enter a different ID."); }
                else if (origin == "") //Ensures that the user does not leave the origin section blank
                { MessageBox.Show("Please enter an origin."); }
                else if (destination == "") //Ensures that the user does not leave the destination section blank
                { MessageBox.Show("Please enter a destination."); }
                else if (coach == "") //Ensures that the user does not leave the coach section blank
                { MessageBox.Show("Please enter a coach."); }
                else if (seat == "") //Ensures that the user does not leave the seat section blank
                { MessageBox.Show("Please enter a seat number."); }
                else if (seatTaken == true) //If we marked the seat as taken earlier, then we throw a popup
                {
                    MessageBox.Show("This seat is occupied, please enter a different seat number or coach.");
                    seatTaken = false; //Additionally, we make sure to set seatTaken back to false, so that this popup doesn't reappear indefinitely, even after being corrected
                }
                else //If everything is validated correct, then we move to the next part
                {
                    //Train fare calculation:
                    float fare = 0; //We initialise the 'fare' float in advance for the sake of scope. This also allows us to reset the cost after each ticket.

                    if ((origin == "Edinburgh (Waverley)" && destination == "London (Kings Cross)") || (origin == "London (Kings Cross)" && destination == "Edinburgh (Waverley)"))
                    { fare = 50; } //If going from Edinburgh to London, or vice versa, then the ticket is set at £50...
                    else
                    { fare = 25; } //...if they're going to or from any other station, it's set at £25.
                    if (firstClass == true)
                    { fare = fare + 10; } //If the seat is first class, the ticket costs 10 more
                    if (AddTrain.list.find(trainID).TrainType == "Sleeper")
                    { fare = fare + 10; } //If the train is a sleeper, the ticket costs 10 more
                    if (cabin == true)
                    { fare = fare + 20; } //If they want a cabin, then it costs another 20 more
                    MessageBox.Show("Your train ticket will cost £" + fare); //We finally give a popup box informing them of how much their ticket will cost

                    hasSeenCost = true; //At the end, we set 'hasSeenCost' to true, which is needed to unlock the ability to actually book the ticket
                    trainExists = false; //We also make sure to disable trainExists back to false so that trains ID input's aren't automatically marked as valid when they shouldn't
                }
            }
            catch { }
        }

        private void Btn_cancel_Click(object sender, RoutedEventArgs e) //Sends the user back to the menu
        {
            MainWindow MainWindow = new MainWindow(); //Creates a new MainWindow Window
            MainWindow.Show(); //Opens said window
            this.Close(); //Closes the current window
        }

        private void Btn_continue_Click(object sender, RoutedEventArgs e)
        {
            if (hasSeenCost == false) //If the user hasn't reviewed their cost (And thus gone through all the necessary validation) previously, the data will not be added
                { MessageBox.Show("Please review your cost before continuing"); }
            else //If they have successfully validated everything, and reviewed their cost, we can finally save their data
            {
                Customer newCustomer = new Customer(); //First we create a new customer
                newCustomer.Name = name; //Gets the name from the user's input
                newCustomer.TrainID = trainID; //Gets the train's ID from the user's input
                newCustomer.CustomerDepartureStation = origin; //Gets the origin from the user's selection
                newCustomer.CustomerArrivalStation = destination; //Gets the destination from the user's selection
                newCustomer.Cabin = cabin; //Notes if they are staying in a cabin from their selection
                newCustomer.FirstClass = firstClass; //Notes if they are staying in first class from their selection
                newCustomer.CoachValue = coach; //Gets the coach value from the user's selection
                newCustomer.SeatNumber = seat; //Gets the seat number from the user's selection
                list.add(newCustomer); //Adds the new customer to the list of customers

                hasSeenCost = false; //Lastly, we make sure to reset 'hasSeenCost' to false, to make sure that they must review the cost before every single booking
            }
        }
    }
}
