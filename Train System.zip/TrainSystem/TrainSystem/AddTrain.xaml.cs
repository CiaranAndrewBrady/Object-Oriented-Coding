﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TrainSystem
{
    /// <summary>
    /// Interaction logic for AddTrain.xaml
    /// </summary>
    public partial class AddTrain : Window
    {

        public static Train store = new Train(); //Creates a new train
        public static TrainList list = new TrainList(); //Creates a new train list

        public AddTrain()
        {
            InitializeComponent();
        }

        private void Btn_continue_Click(object sender, RoutedEventArgs e) //When the Continue button is clicked
        {
            //Initialisation of variables in advance, so as to keep scope consistant
            string intermediate = ""; //Intermediate is going to contain any intermediate stops that a non-express train makes
            string destination = ""; //Destination is going to be the train's destination, either Edinburgh or London
            bool firstClass = false; //firstClass and isSleeper are variables saved within the train
            bool isSleeper = false;
            bool uniqueID = true; //uniqueID is used as a simple way of causing a popup-up if the train ID input has already been used 

            //Get data from user's inputs
            string ID = txt_ID.Text; // User inputs Train's ID, saved as string
            string departure = ddl_departure.Text; // User selects departure destination
            if (departure == "Edinburgh (Waverley)") // The destination will always be the opposite of the departure
                { destination = "London (Kings Cross)"; }
                else { destination = "Edinburgh (Waverley)"; }
            string type = ddl_type.Text; // User selects the type of train
            if (cbx_intermediatePetersborough.IsChecked == true) // This is a large string of concatenations...
                { intermediate = "Peterborough "; }
            if (cbx_intermediateDarlington.IsChecked == true) // ...If one of the checkboxes is selected...
                { intermediate = intermediate + "Darlington "; }
            if (cbx_intermediateYork.IsChecked == true) // ...Then the relevant word will be concanenated
                { intermediate = intermediate + "York "; }
            if (cbx_intermediateNewcastle.IsChecked == true)
                { intermediate = intermediate + "Newcastle "; }
            string hours = ddl_timeHours.Text; //We keep track of hours separately from 'time' for the sake of ensuring that a sleeper runs after 9pm
            DateTime time = DateTime.Parse(ddl_timeHours.Text + ":" + ddl_timeMinutes.Text); //User selects hours and minutes, which are then parsed into a DateTime data type
            DateTime date = DateTime.Parse(dpk_departureDay.ToString()); // User selects the date from the calender
            if (type == "Sleeper") // If train type is a sleeper, then isSleeper will be true
                { isSleeper = true; }
            if (cbx_firstClass.IsChecked == true) // If the checkbox is ticked, firstClass will be true
                { firstClass = true; }

            //Performs validation to ensure train details entered correctly
            foreach (Train counter in TrainList._trainList) //Performs a loop that checks every single train saved
            {
                if (counter.TrainID == ID) //If we find that the user's input TrainID has already been used...
                {
                    uniqueID = false; //...then we switch unique ID to false. This variable allows us to throw up an error in the same else if as everything else, without putting it all into the foreach loop
                }
            }
            try
            {
                if (ID.Length != 4) //Gives a popup if the ID isn't 4 characters
                { MessageBox.Show("Invalid Train ID. IDs must be exactly 4 characters."); }
                else if (uniqueID == false) //If UniqueID is false, then that means we tripped the earlier if statement in the foreach
                { MessageBox.Show("Invalid train ID. This ID is already in use."); }
                else if (departure == "") //Gives a popup to ensure departure isn't left blank: No validation is needed for destination, as it is based off of departure's value
                { MessageBox.Show("Please enter a departure station."); }
                else if (type == "") //Gives a popup to ensure type isn't left blank
                { MessageBox.Show("Please enter a train type."); }
                else if (time.ToString("HH:mm") == "") //Briefly converts time to String, to give a popup if it's blank, and ensure it's filled in
                { MessageBox.Show("Please enter a time."); }
                else if (date.ToString("dd/MM/yyyy") == "") //Briefly converts date to String, to give a popup if it's blank, and ensure it's filled in
                { MessageBox.Show("Please enter a date."); }
                else if (type == "Sleeper" && Convert.ToInt32(hours) < 21) //This converts the variable 'hours' (which we kept earlier) to 21, which is 9pm in decimal time, to ensure that Sleepers depart afterwards
                { MessageBox.Show("Sleepers must depart at 9pm at the earliest"); }
                else if (type == "Express" && intermediate != "") //Gives a popup if the user has tried to make an Express train AND give intermediate stops
                { MessageBox.Show("Express trains may not make intermediate stops."); }
                else //If none of the previous problems were found...
                {
                    //Adds all of the user's data to the list
                    Train newTrain = new Train(); //Creates a new train in the train class
                    newTrain.TrainID = ID; //Takes the input ID and stores it in the new train
                    newTrain.DepartureStation = departure; //Takes the input departure and stores it in the new train
                    newTrain.DestinationStation = destination; //Takes the calculated destination and stores it in the new train
                    newTrain.TrainType = type; //Takes the input train type and stores it in the new train
                    newTrain.Intermediates = intermediate; //Takes the input intermediates and stores them in the new train
                    newTrain.Time = time; //Takes the input time and stores it in the new train
                    newTrain.Date = date; //Takes the input date and stores it in the new train
                    newTrain.IsSleeper = isSleeper; //Checks if the train is a sleeper and stores this data in the new train
                    newTrain.IsFirstClass = firstClass; //Checks if the train offers first class and stores this data in the new train
                    list.add(newTrain); //Finally, we add the newly created train into the list we keep
                }
            }
            catch
            {
            }
        }

        private void Btn_cancel_Click(object sender, RoutedEventArgs e) //Allows the user to return to the main menu
        {
            MainWindow MainWindow = new MainWindow(); //Creates a new copy of the MainWindow Window
            MainWindow.Show(); //Shows said window
            this.Close(); //Closes the current window
        }
    }
}
