﻿using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TrainSystem
{
    /// <summary>
    /// Interaction logic for SearchTrains.xaml
    /// </summary>
    public partial class SearchTrains : Window
    {
        public SearchTrains()
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, RoutedEventArgs e) //Allows the user to return to the main menu
        {
            MainWindow MainWindow = new MainWindow(); //Creates a new MainWindow Window
            MainWindow.Show(); //Shows said window
            this.Close(); //Closes the current window
        }

        private void btn_stationSearch_Click(object sender, RoutedEventArgs e) //Allows the user to search by station
        {
            ddp_StationSearchResults.Items.Clear(); //First, we clear the combobox from all previous search results

            foreach (Train counter in TrainList._trainList) //Runs through the entire train list
            {
                if ((counter.DepartureStation == ddl_origin.Text || counter.Intermediates.Contains(ddl_origin.Text)) && (counter.DestinationStation == ddl_destination.Text || counter.Intermediates.Contains(ddl_destination.Text)))
                { //If we find a value where the train's origin AND destination both match up with what the user input, then we print out the train's ID, type, date, and time of departure.
                    ddp_StationSearchResults.Items.Add(counter.TrainID + " - " + counter.TrainType + " - " + counter.Date.ToString("dd/MM/yyyy") + " - " + counter.Time.ToString("HH:mm"));
                }
            }
        }

        private void btn_dateSearch_Click(object sender, RoutedEventArgs e) //Allows the user to search by date
        {
            DateTime date = DateTime.Parse(dpk_searchDay.ToString()); //Here, we quickly create variable 'date' to store as a DateTime value, for the same of comparing against the list more easily

            ddp_DateSearchResults.Items.Clear(); //First, we clear the combobox from all previous search results

            foreach (Train counter in TrainList._trainList) //Runs through the entire train list
            {
                if (counter.Date == date) //If we find a value where the date matches the user's selected date...
                {
                    ddp_DateSearchResults.Items.Add(counter.TrainID + " - " + counter.TrainType); //...then we add it to the combobox
                }
            }
        }

        private void btn_IDSearch_Click(object sender, RoutedEventArgs e) //Allows the user to search by the train's ID
        {
            string ID = txt_ID.Text; //Here, we convert the ID to a string for ease of comparison

            ddp_IDSearchResults.Items.Clear(); //First, we clear the combobox from all previous search results

            foreach (Customer counter in CustomerList._customerList) //Runs through the entire customer list
            {
                if (counter.TrainID == ID) //If we find a value where the train ID matches the user's selected date...
                {
                    ddp_IDSearchResults.Items.Add(counter.Name + " - " + counter.CoachValue + counter.SeatNumber); //...then we add it to the combobox
                }
            }
        }
    }
}
