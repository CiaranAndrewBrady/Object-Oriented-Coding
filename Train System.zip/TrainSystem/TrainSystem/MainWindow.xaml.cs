﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataLayer;
using BusinessObjects;

namespace TrainSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


    public partial class MainWindow : Window
    {
        public MainWindow() //Code is now open
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, RoutedEventArgs e) //Closes the program
        {
            this.Close(); //This line closes the program
        }

        private void btn_addCustomer_Click(object sender, RoutedEventArgs e) //Lets user add a new customer
        {
            AddCustomer AddCustomer = new AddCustomer(); //Creates a new AddCustomer Window
            AddCustomer.Show(); //Shows said window
            this.Close(); //Closes the current window
        }

        private void btn_addTrain_Click(object sender, RoutedEventArgs e) //Lets user add a new train
        {
            AddTrain AddTrain = new AddTrain(); //Creates a new AddTrain Window
            AddTrain.Show(); //Shows said window
            this.Close(); //Closes the current window
        }

        private void btn_searchTrains_Click(object sender, RoutedEventArgs e) //Lets user perform search functions
        {
            SearchTrains SearchTrains = new SearchTrains(); //Creates a new SearchTrains Window
            SearchTrains.Show(); //Shows said window
            this.Close(); //Closes the current window
        }

        private void Btn_save_Click(object sender, RoutedEventArgs e) //Saves the current data to a .xml file
        {
            SaveLoad.Save(); //Runs the Save method in the SaveLoad project in the Data Layer
        }

        private void Btn_load_Click(object sender, RoutedEventArgs e) //Loads data from the .xml file
        {
            // This is currently unimplimented
        }
    }
}
