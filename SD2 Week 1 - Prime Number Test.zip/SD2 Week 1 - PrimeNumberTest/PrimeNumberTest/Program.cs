﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberTest
{
    class Program
    {
        static bool IsPrime(int n) //Function which will test if the number is prime
        {
            if (n > 1)
            {
                return Enumerable.Range(1, n).Where(x => n % x == 0)
                                 .SequenceEqual(new[] { 1, n });
            }

            return false;
        }

        static void Main(string[] args)
        {
            for (; ; )
            {
                Console.Write("Please input a number: "); //Get number from user
                int n = int.Parse(Console.ReadLine());
                if (IsPrime(n))
                {
                    Console.WriteLine("{0} is a prime number", n); //If the function returns true, it's prime
                }
                else
                {
                    Console.WriteLine("{0} is not a prime number", n); //If it doesn't, it's false
                }
            }
        }
    }
}