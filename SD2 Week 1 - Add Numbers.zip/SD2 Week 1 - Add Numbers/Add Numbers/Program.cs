﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Add_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a series of numbers, with commas between them."); //Get input from user
            string input = Console.ReadLine(); //Assign unput to string 'input'
            int[] numbers = input.Split(',').Select(Int32.Parse).ToArray(); //Splits string 'input' at commas. Stores new values as an int array

            int total = 0; //Declare a int 'total'
            for (int i = 0; i < numbers.Length; i++) //Loop which will run once for each value in the list, moves to next value each time
            {
                total += numbers[i]; //Adds the current value to total
            }

            Console.WriteLine(total); //Prints total

            Console.WriteLine("Press return to exit"); //Requires user to press enter to exit the program
            Console.ReadLine();
        }

    }
}